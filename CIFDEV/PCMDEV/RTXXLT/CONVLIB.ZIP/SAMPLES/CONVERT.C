/*---------------------------------------------------------------------------------*
 *  FILE      : Convert.c
 *  DATE      : 8/18/95
 *  DESCR     : main program file containing main() entry point;
 *                - calls ParseCommandLine() defined in parser.c to parse the
 *                  command line arguments,
 *                - for each chunk of input data read from input file, do:
 *                  - calls ConvertToLin() to convert original format to LIN
 *                  - calls ConvertRate() to convert to to destination rate
 *                  - calls ConvertFromLin() to convert to destination format
 *                  - writes the result data from output buffer to output file
 *   1/15/96 - read up to only wh.datasize from file because some wave utility
 *             append signature info to the end
 *---------------------------------------------------------------------------------*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <fcntl.h>
#include <io.h>
#include <conio.h>
#include <errno.h>
#include <malloc.h>
#include <math.h>
#include "parser.h"
#include "convert.h"
#include "waveutil.h"

#include "..\include\cnv_all.h"

unsigned short  *inputBuffer;           // these buffer are use interchangeably during the conversion process
unsigned short  *outputBuffer;

#define MAX_BUF_SIZE       (0xffff/2)   // cannot use UINT_MAX since we are only using malloc()
                                        // in the local heap

/*---------------------------------------------------------------------------------*

   FUNCTION  : main
   Purpose   : program entry point
   Arguments : argc - argument count
   Globals   : none
   Return    : 0 for successful execution
               none-zero for any error
*---------------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    CONVERT *cp=NULL;
    WAVEHEADER *whp1=NULL, *whp2=NULL;
    int fd1=0, fd2=0, i; 
    unsigned int  actualbytesread, bytes_written, bytes_convertthisbuf;

    unsigned long total_bytes_written=0;
    unsigned int  inbitspersample, outbitspersample, inchunksize, outchunksize;
    unsigned long inputlength, linbuflength, ratebuflength, outbuflength, maxbuflength;
    long actualwavdatasize;
    
    cp = ConvertCreate(NULL, NULL);  /* intialize the CONVERT structure */

    ParseCommandLine(argc,argv, cp);        /* parse the command line options */
    CheckFiles(cp);                         /* validate the input/output file */

    fd1=_open(cp->inputFilename,_O_RDONLY | _O_BINARY );
    if(fd1==-1)     Error("Opening INPUT FILE \"%s\" \n",cp->inputFilename);
    
    fd2=_open(cp->outputFilename,_O_RDWR | _O_CREAT | _O_EXCL | _O_BINARY, _S_IREAD | _S_IWRITE);    

    if( errno == EEXIST )       /* if OVERWRITE option not specified, give prompt */
    {
        char ch;
        if      (cp->overWrite == FALSE) 
        {
            fprintf(stderr, "Target %s exists. Overwrite? ", cp->outputFilename );
            ch = getchar();
            if( (ch == 'y') || (ch == 'Y') )
                fd2 = _open( cp->outputFilename, _O_BINARY | _O_RDWR |
                                _O_CREAT | _O_TRUNC, _S_IREAD | _S_IWRITE );
            else return 0;
            fprintf(stderr, "\n" );
        }
        else if (cp->overWrite == TRUE)
            fd2 = _open( cp->outputFilename, _O_BINARY | _O_RDWR |
                            _O_CREAT | _O_TRUNC, _S_IREAD | _S_IWRITE );
    }
    else if(fd2==-1)     Error("Opening OUTPUT FILE \"%s\" \n",cp->outputFilename);
    

    /* if output type is specified as WAV 8/16 bit, set the WAV format header */
    if( (cp->outputType == WAV8) || (cp->outputType == WAV16) )
    {
        long nSamplesPerSec=11025;
        int  wBitsPerSample= (cp->outputType==WAV8)? 8: 16;
        
        switch(cp->outputSampleRate) {
            case  8: nSamplesPerSec =  8000; break;        
            case 11: nSamplesPerSec = 11025; break;
            case 22: nSamplesPerSec = 22050; break;
            case 44: nSamplesPerSec = 44100; break;
        }
        whp2  = CreateWaveHeader( nSamplesPerSec, (short)wBitsPerSample );
        if( _write(fd2, whp2, sizeof(WAVEHEADER)) == -1 ) Error("Writing OUTPUT FILE %s",cp->outputFilename);
        
    }

    /* this is done again for input type WAVxx, since we'll be checking the input file */
    /* if input type is specified as WAV 8/16 bit, set the WAV format header, check it against actual input file */    
    /* what the user enter may not be right, so must update our structure to the right data */
    if( (cp->inputType == WAV8) || (cp->inputType == WAV16) )
    {
        whp1  = CreateWaveHeader( 0L, 0 );
        if( _read(fd1, whp1, sizeof(WAVEHEADER)) == -1 ) Error("Reading INPUT FILE %s",cp->inputFilename);
        CheckWaveHeader(whp1);
       
        cp->inputSampleRate    = (int)(whp1->nSamplesPerSec/1000L);
        cp->inputBitsPerSample = (int)(whp1->wBitsPerSample);
        cp->inputType          = (cp->inputBitsPerSample==8)? WAV8: WAV16;

        SetRateType(cp);
        
        if (cp->convertRateCb) CVC_ConvertDestroy(cp->convertRateCb);
        if (cp->inputTypeCb)  CVC_WaveDestroy(cp->inputTypeCb);
        
        if(cp->rateType != CVT_CONV01TO01)        
            cp->convertRateCb = CVC_ConvertCreate(cp->rateType);        
        if (cp->inputType == WAV8)
            cp->inputTypeCb = CVC_WaveCreate(CVT_MONO08);
        else if (cp->inputType == WAV16)                  
            cp->inputTypeCb = CVC_WaveCreate(CVT_MONO16); 
    }          

    /* calculate the input size to be a whole multiple of samples */
        inchunksize     = (unsigned int)(cp->inputSampleRate);
        outchunksize    = (unsigned int)(cp->outputSampleRate);
        inbitspersample =       cp->inputBitsPerSample;
        outbitspersample =      cp->outputBitsPerSample;
        
        /* use maximum input size possible ... while making sure the maxbuflength does not exceed 64K */
        inputlength   = (cp->inputBitsPerSample * inchunksize * 16);
        linbuflength  = (inputlength   * 16 / cp->inputBitsPerSample);
        ratebuflength = (linbuflength  * outchunksize / inchunksize);
        outbuflength  = (ratebuflength * cp->outputBitsPerSample / 16);
        maxbuflength  = max( linbuflength, max(ratebuflength, outbuflength));

        /* double each length up to maximum of 64K */
        while (maxbuflength < MAX_BUF_SIZE )
        {
            inputlength    = inputlength   * 2;
            linbuflength   = linbuflength  * 2;
            ratebuflength  = ratebuflength * 2;
            outbuflength   = outbuflength  * 2;
            maxbuflength   = max( linbuflength, max(ratebuflength, outbuflength));
        }     
        
        inputBuffer  = (unsigned short *)malloc((unsigned int)maxbuflength);
        outputBuffer = (unsigned short *)malloc((unsigned int)maxbuflength);
        cp->maxInpSize = (unsigned int)inputlength;
    
    for (i=0; i < 24; i++) putchar('\n');
    fprintf(stderr,"�����������������������������������������������������������������������������ͻ\n");
    fprintf(stderr,"� RHETOREX           �          CONVERT UTILITY          �  Version: 2.00     �\n");
    fprintf(stderr,"�����������������������������������������������������������������������������ͼ\n");
    fprintf(stderr," input  filename     :   %s\n",          cp->inputFilename       );
    fprintf(stderr," input  type         :   %s\n",          TypeStr(cp->inputType)  );
    fprintf(stderr," input  sample rate  :   %2d Khz\n",     cp->inputSampleRate     );
    fprintf(stderr,"�������������������������������������������������������������������������������\n");
    fprintf(stderr," output filename     :   %s\n",          cp->outputFilename      );
    fprintf(stderr," output type         :   %s\n",          TypeStr(cp->outputType) );
    fprintf(stderr," output sample rate  :   %2d Khz\n",     cp->outputSampleRate    );
    fprintf(stderr,"�������������������������������������������������������������������������������\n");
    fprintf(stderr,"\n                          CONVERTING PLEASE WAIT \n");


    
    
    /* read each block of data upto maxInpSize, do the conversion & write result to output file */
    /* for WAV8 & WAV16: watch for signature at end of file by reading only wavehdr->datasize   */
    if( (cp->inputType == WAV8) || (cp->inputType == WAV16) )
    {   
        actualwavdatasize = (long)whp1->datasize;
        //fprintf(stderr," whp1->datasize %8ld maxInpSize %8u actualwavdatasize %8ld \n", whp1->datasize, cp->maxInpSize,    actualwavdatasize );        
    }
    else 
        actualwavdatasize = (long)cp->maxInpSize;
    
    while((actualbytesread=_read(fd1, inputBuffer,(int)min((unsigned long)actualwavdatasize, (unsigned long)cp->maxInpSize))) > 0)
    {
        cp->inpBufSize = actualbytesread;
        
        cp->inpBufPtr  = inputBuffer;
        cp->outBufPtr  = outputBuffer;
        cp->outBufSize = (unsigned int)linbuflength;
        cp->inpBufSize >>=1;            // is actually the # of LINEAR samples in the input buffer
        ConvertToLin(cp);               /* 1st, convert it to LIN */

        cp->inpBufPtr  = outputBuffer;     /* switch the input <-> output */
        cp->outBufPtr  = inputBuffer;
        cp->inpBufSize = *cp->outBufLen;
        cp->outBufSize = (unsigned int)ratebuflength;
        ConvertRate(cp);                /* 2nd, convert the LIN to appropriate rate */

        cp->inpBufPtr  = inputBuffer;      /* switch the output <-> input */
        cp->outBufPtr  = outputBuffer;
        cp->inpBufSize = *cp->outBufLen;
        cp->outBufSize = (unsigned int)outbuflength;
        ConvertFromLin(cp);             /* finally, convert LIN to destination format */

        /* write output buffer to file */
        //bytes_convertthisbuf = (unsigned int)((unsigned long)sizeof(outputBuffer[0]) * (*cp->outBufLen));
        
        bytes_convertthisbuf = (sizeof(outputBuffer[0]) * (unsigned int)(*cp->outBufLen));
        bytes_written = _write(fd2, outputBuffer, bytes_convertthisbuf );
        total_bytes_written = (unsigned long)(total_bytes_written + bytes_written);
        putchar('.');
        
        // fprintf(stderr," read %u out %lu wrote %u converted %u total %lu \n", 
        //                  actualbytesread, *cp->outBufLen, bytes_written, bytes_convertthisbuf, total_bytes_written);

        if( (cp->inputType == WAV8) || (cp->inputType == WAV16) )
            actualwavdatasize -= (long)actualbytesread;
        //fprintf(stderr," data read %8d - left :   %8ld bytes\n", actualbytesread, actualwavdatasize );
        
        if (actualwavdatasize <0)
            break; 
    }
    
    /* if ouput type is specified as WAV 8/16 bit, must update the  header file size */
    if( (cp->outputType == WAV8) || (cp->outputType == WAV16) )
        UpdateWaveHeaderSize(fd2, total_bytes_written);

    fprintf(stderr,"\n\n");
    fprintf(stderr,"------------------------------------------------------------------------------\n");
    fprintf(stderr," input  file length  :   %5ld bytes\n", _filelength(fd1) );
    fprintf(stderr," output file length  :   %5ld bytes\n", _filelength(fd2) );
    fprintf(stderr,"------------------------------------------------------------------------------\n");

    _close(fd1); 
    _close(fd2);        

    ConvertDestroy(cp);
    free(inputBuffer);
    free(outputBuffer);
    
    if (whp1) DestroyWaveHeader(whp1);
    if (whp2) DestroyWaveHeader(whp2);
    return 0; 
}   


/*---------------------------------------------------------------------------------*
   FUNCTION  : ConvertToLin
   Purpose   : calls CVC_xxxx() functions to convert to LIN format
   Arguments : cp - pointer to CONVERT structure
   Globals   : none
   Return    : none
*---------------------------------------------------------------------------------*/
void ConvertToLin(CONVERT *cp)           
{
    switch(cp->inputType)
    {
        case OKI24  :   CVC_ExpandOki24(    cp->inputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case OKI32  :   CVC_ExpandOki32(    cp->inputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case RHET24 :   CVC_ExpandRhet24(   cp->inputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case RHET32 :   CVC_ExpandRhet32(   cp->inputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case ULAW   :   CVC_ExpandULAW  (   cp->inputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case ALAW   :   CVC_ExpandALAW  (   cp->inputTypeCb, 
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case WAV16  :   CVC_Wave16toLin (   cp->inputTypeCb,    
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case WAV8   :   CVC_Wave8toLin  (   cp->inputTypeCb,    
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case LIN    :   memcpy( cp->outBufPtr, cp->inpBufPtr, (unsigned int)min(cp->inpBufSize, cp->outBufSize)*2 ); 
                        *cp->inpUsed = *cp->outBufLen = min(cp->inpBufSize, cp->outBufSize);
                        break;
    }    
}

/*---------------------------------------------------------------------------------*
   FUNCTION  : ConvertFromLin
   Purpose   : calls CVC_xxxx() functions to convert from LIN to destination format
   Arguments : cp - pointer to CONVERT structure
   Globals   : none
   Return    : none
*---------------------------------------------------------------------------------*/
void ConvertFromLin(CONVERT *cp)           
{
    switch(cp->outputType)
    {
        case OKI24  :   CVC_CompressOki24(  cp->outputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case OKI32  :   CVC_CompressOki32(  cp->outputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case RHET24 :   CVC_CompressRhet24( cp->outputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case RHET32 :   CVC_CompressRhet32( cp->outputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case ULAW   :   CVC_CompressULAW  ( cp->outputTypeCb,
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case ALAW   :   CVC_CompressALAW  ( cp->outputTypeCb, 
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case WAV16  :   CVC_LintoWave16   ( cp->outputTypeCb, 
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case WAV8   :   CVC_LintoWave8    ( cp->outputTypeCb, 
                                            cp->inpBufPtr,
                                            cp->inpBufSize,
                                            cp->inpUsed,
                                            cp->outBufPtr,
                                            cp->outBufSize,
                                            cp->outBufLen   );  break;  
        case LIN    :   memcpy( cp->outBufPtr, cp->inpBufPtr, (unsigned int)min(cp->inpBufSize, cp->outBufSize)*2 ); 
                        *cp->inpUsed = *cp->outBufLen = min(cp->inpBufSize, cp->outBufSize);
                        break;
    }    
}


/*---------------------------------------------------------------------------------*
   FUNCTION  : ConvertRate
   Purpose   : calls CVC_Convertxxxx() functions to convert to destination
               rate; call after originalformat is converted to LIN
   Arguments : cp - pointer to CONVERT structure
   Globals   : none
   Return    : none
*---------------------------------------------------------------------------------*/
void ConvertRate(CONVERT *cp)           
{
    switch(cp->rateType)
    {
        case CVT_CONV08TO16 :   CVC_Convert08to16 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV16TO08 :   CVC_Convert16to08 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV08TO11 :   CVC_Convert08to11 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV08TO22 :   CVC_Convert08to22 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV08TO44 :   CVC_Convert08to44 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV11TO08 :   CVC_Convert11to08 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV11TO22 :   CVC_Convert11to22 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV11TO44 :   CVC_Convert11to44 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV22TO08 :   CVC_Convert22to08 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV22TO11 :   CVC_Convert22to11 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV22TO44 :   CVC_Convert22to44 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV44TO08 :   CVC_Convert44to08 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV44TO11 :   CVC_Convert44to11 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV44TO22 :   CVC_Convert44to22 ( cp->convertRateCb,
                                                    cp->inpBufPtr,
                                                    cp->inpBufSize,
                                                    cp->inpUsed,
                                                    cp->outBufPtr,
                                                    cp->outBufSize,
                                                    cp->outBufLen   );  break;  
        case CVT_CONV01TO01 :   memcpy( cp->outBufPtr, cp->inpBufPtr, (unsigned int)min(cp->inpBufSize, cp->outBufSize)*2 ); 
                                *cp->inpUsed = *cp->outBufLen = min(cp->inpBufSize, cp->outBufSize);
                                break;
    }    
}


/*---------------------------------------------------------------------------------*
   FUNCTION  : ConvertCreate
   Purpose   : create & initialialize CONVERT structure
   Arguments : inpBufferPtr - pointer to array of integer for input storage
               outBufferPtr - pointer to array of integer for output storage
   Globals   : none
   Return    : pointer to CONVERT structure
*---------------------------------------------------------------------------------*/
CONVERT *ConvertCreate(unsigned short *inpBufferPtr, unsigned short *outBufferPtr)
{
    CONVERT *cp;
    CONVERT convert     = {    "",            /*   inputFilename[]  */  
                               LIN,           /*   inputType        */ 
                               8,             /*   inputSampleRate  */ 
                               16,            /*   inputBitsPerSample */
                               NULL,          /*  *inputTypeCb      */ 
                               "",            /*   outputFilename[] */ 
                               LIN,           /*   outputType       */ 
                               8,             /*   outputSampleRate */ 
                               16,            /*   outputBitsPerSample*/
                               NULL,          /*  *outputTypeCb     */ 
                               NULL,          /*  *convertRateCb    */ 
                               CVT_CONV01TO01,/*   rateType         */
                               FALSE,         /*   overWrite        */
                               0,             /*   maxInpSize       */
                               inpBufferPtr,  /*  *inpBufPtr        */ 
                               0,             /*   inpBufSize       */ 
                               NULL,          /*  *inpUsed          */ 
                               outBufferPtr,  /*  *outBufPtr        */ 
                               0,             /*   outBufSize       */ 
                               NULL           /*  *outBufLen        */   
                                                };
                                        
    
    convert.inpUsed     = malloc(sizeof(*convert.inpUsed));
    *convert.inpUsed    = 0;
    convert.outBufLen   = malloc(sizeof(*convert.outBufLen));
    *convert.outBufLen  = 0;
    
    cp = malloc(sizeof(convert));
    *cp = convert;

    return(cp);
}

/*---------------------------------------------------------------------------------*
   FUNCTION  : ConvertDestroy
   Purpose   : frees the memory & structures used within the CONVERT members
   Arguments : cp - pointer to CONVERT structure
   Globals   : none
   Return    : none
*---------------------------------------------------------------------------------*/
void ConvertDestroy(CONVERT *cp)
{
    switch(cp->inputType)
    {
        case OKI24  : CVC_Oki24Destroy(cp->inputTypeCb);               break; 
        case OKI32  : CVC_Oki32Destroy(cp->inputTypeCb);               break; 
        case RHET24 : CVC_Rhet24Destroy(cp->inputTypeCb);              break;
        case RHET32 : CVC_Rhet32Destroy(cp->inputTypeCb);              break; 
        case ULAW   : CVC_PCMDestroy(cp->inputTypeCb);                 break; 
        case ALAW   : CVC_PCMDestroy(cp->inputTypeCb);                 break; 
        case WAV16  : CVC_WaveDestroy(cp->inputTypeCb);                break; 
        case WAV8   : CVC_WaveDestroy(cp->inputTypeCb);                break;   
        case LIN    :                                                  break;         
    }    
    switch(cp->outputType)
    {
        case OKI24  : CVC_Oki24Destroy(cp->outputTypeCb);              break; 
        case OKI32  : CVC_Oki32Destroy(cp->outputTypeCb);              break; 
        case RHET24 : CVC_Rhet24Destroy(cp->outputTypeCb);             break;
        case RHET32 : CVC_Rhet32Destroy(cp->outputTypeCb);             break; 
        case ULAW   : CVC_PCMDestroy(cp->outputTypeCb);                break; 
        case ALAW   : CVC_PCMDestroy(cp->outputTypeCb);                break; 
        case WAV16  : CVC_WaveDestroy(cp->outputTypeCb);               break; 
        case WAV8   : CVC_WaveDestroy(cp->outputTypeCb);               break;   
        case LIN    :                                                  break;         
    }    
    
    if (cp->rateType != CVT_CONV01TO01)
        CVC_ConvertDestroy(cp->convertRateCb);
            
    //free(cp->inputFilename);
    //free(cp->outputFilename);
    free(cp->inpUsed);  
    free(cp->outBufLen);
    free(cp);
}

/*---------------------------------------------------------------------------------*
   FUNCTION    CheckFiles
   Purpose   : if the output file name is not supply in the command line,
               constructs the output file name with appropriate extension
               associated the output type
   Arguments : cp - pointer to CONVERT structure containing the conversion
               information.
   Globals   : none
   Return    : none
*---------------------------------------------------------------------------------*/
void CheckFiles(CONVERT *cp)
{
    char *file_ext_table[] = { "O32","O24", "R32", "R24", "ULW", "ALW", "WAV", "WAV", "LIN" };
    int n;
    
    if (strlen(cp->inputFilename) == 0 )
        Error("No input filename specified");
    if (strlen(cp->outputFilename) == 0)
    {
        n=strlen(cp->inputFilename)-strlen(strrchr(cp->inputFilename,'.'));
        sprintf(cp->outputFilename,"%.*s.%s",n,cp->inputFilename,file_ext_table[cp->outputType]);
    }   

}            

/*---------------------------------------------------------------------------------*
   FUNCTION  : TypeStr   
   Purpose   : associate the format type with a text string for display
   Arguments : it - the format type
   Globals   : none
   Return    : pointer to to the string of text
*---------------------------------------------------------------------------------*/
char *TypeStr(int it)
{
    static char str[80];
    switch(it)
    {
        case OKI24 :    strcpy(str,"STANDARD          24 Kbit/sec");    break;
        case OKI32 :    strcpy(str,"STANDARD          32 Kbit/sec");    break;
        case RHET24:    strcpy(str,"RHETOREX          24 Kbit/sec");    break;
        case RHET32:    strcpy(str,"RHETOREX          32 Kbit/sec");    break;
        case ULAW:      strcpy(str,"ULAW PCM          64 Kbit/sec");    break;
        case ALAW:      strcpy(str,"ALAW PCM          64 Kbit/sec");    break;
        case WAV8:      strcpy(str,"WAVE MONO  8 bit             ");    break;
        case WAV16:     strcpy(str,"WAVE MONO 16 bit             ");    break;
        case LIN:       strcpy(str,"LINEAR           128 Kbit/sec");    break;
    }   
    return str;
}    
