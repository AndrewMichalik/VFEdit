/*
 * Copyright 1992 by Jutta Degener and Carsten Bormann, Technische
 * Universitaet Berlin.  See the accompanying file "COPYRIGHT" for
 * details.  THERE IS ABSOLUTELY NO WARRANTY FOR THIS SOFTWARE.
 */

/* $Header: /home/kbs/jutta/src/gsm/gsm-1.0/src/RCS/gsm_option.c,v 1.1 1992/10/28 00:15:50 jutta Exp $ */

#include "private.h"

#include "gsm.h"
#include "proto.h"

long gsm_option P3((r, opt, val), gsm r, long opt, long WFAR * val)
{
		long 	result = -1;

		switch (opt) {
		case GSM_OPT_VERBOSE:
#ifndef NDEBUG
				result = r->verbose;
				if (val) r->verbose = (char) (*val);
#endif
				break;

		case GSM_OPT_FAST:

#if 	defined(FAST) && defined(USE_FLOAT_MUL)
				result = r->fast;
				if (val) r->fast = !!*val;
#endif
				break;

		default:
				break;
		}
		return result;
}
