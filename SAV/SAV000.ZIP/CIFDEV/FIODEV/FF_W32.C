/************************************************************************/
/* File Find Functions: FF_W32.c                        V3.00  07/15/94 */
/* Copyright (c) 1987-1997 Andrew J. Michalik                           */
/*                                                                      */
/************************************************************************/
#include "windows.h"                    /* Windows SDK definitions      */
#include "..\os_dev\winmem.h"           /* Generic memory supp defs     */
#include "genfio.h"                     /* Generic File I/O definitions */
#include "fiosup.h"                     /* File I/O support definitions */

#include <string.h>                     /* String manipulation funcs    */
#include <dos.h>                        /* DOS low-level routines       */

/************************************************************************/
/*                      External References                             */
/************************************************************************/
extern  W32GLO  W32Glo;                 /* Win 32 Library Globals       */

/************************************************************************/
/************************************************************************/
#define _MAX_PATH    260                /* max. length of full pathname */

/************************************************************************/
/*          Library model independant file find functions               */
/************************************************************************/
unsigned __cdecl l_dos_findfirst (const char FAR *filename, unsigned attrib,
                    struct _find_t FAR *fileinfo)
{
    static  struct _find_t  fiLocInf;
    static  char            szLocNam[_MAX_PATH];
    unsigned                uiRetCod;

    /********************************************************************/
    /********************************************************************/
    _fstrncpy (szLocNam, filename, _MAX_PATH);
    _fmemcpy  (&fiLocInf, fileinfo, sizeof (fiLocInf)); 
    uiRetCod = _dos_findfirst (szLocNam, attrib, &fiLocInf);
    _fmemcpy  (fileinfo, &fiLocInf, sizeof (fiLocInf));
    return (uiRetCod);
}

unsigned __cdecl l_dos_findnext (struct _find_t FAR *fileinfo) 
{
    static  struct _find_t  fiLocInf;
    unsigned                uiRetCod;

    /********************************************************************/
    /********************************************************************/
    _fmemcpy  (&fiLocInf, fileinfo, sizeof (fiLocInf)); 
    uiRetCod = _dos_findnext (&fiLocInf);
    _fmemcpy  (fileinfo, &fiLocInf, sizeof (fiLocInf));
    return (uiRetCod);
}

/************************************************************************/
/************************************************************************/
#include "wownt16.h"                    /* Win on Win 16 bit I/F        */

typedef struct _FILETIME {
    DWORD   dwLowDateTime;
    DWORD   dwHighDateTime;
} FILETIME, *PFILETIME, FAR *LPFILETIME;
typedef struct _WIN32_FIND_DATAA {
    DWORD   dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD   nFileSizeHigh;
    DWORD   nFileSizeLow;
    DWORD   dwReserved0;
    DWORD   dwReserved1;
    char    cFileName[ _MAX_PATH ];
    char    cAlternateFileName[ 14 ];
    BYTE    bShtBlk[64];                /* Added to support short names */
} WIN32_FIND_DATAA, *PWIN32_FIND_DATAA, FAR *LPWIN32_FIND_DATAA;
typedef struct _SECURITY_ATTRIBUTES { 
    DWORD  nLength; 
    LPVOID lpSecurityDescriptor; 
    DWORD  bInheritHandle; 
} SECURITY_ATTRIBUTES; 

#define FILE_ATTRIBUTE_READONLY         0x00000001L  
#define FILE_ATTRIBUTE_HIDDEN           0x00000002L  
#define FILE_ATTRIBUTE_SYSTEM           0x00000004L  
#define FILE_ATTRIBUTE_DIRECTORY        0x00000010L  
#define FILE_ATTRIBUTE_ARCHIVE          0x00000020L  
#define FILE_ATTRIBUTE_NORMAL           0x00000080L  
#define FILE_ATTRIBUTE_TEMPORARY        0x00000100L  
#define FILE_ATTRIBUTE_COMPRESSED       0x00000800L  
#define CREATE_ALWAYS                   0x00000002L  

#define INVALID_HANDLE_VALUE            ((DWORD) -1L)

DWORD   WINAPI  FindFirstFileA (LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);
BOOL    WINAPI  FindNextFileA  (DWORD  hFindFile,  LPWIN32_FIND_DATAA lpFindFileData);
BOOL    WINAPI  FindClose      (DWORD  hFindFile);

DWORD   WINAPI  CreateFileA    (LPCSTR lpFileName, DWORD dwDesiredAccess,    
                                DWORD dwShareMode, LPVOID lpSecurityAttributes,
                                DWORD dwCreationDistribution, DWORD dwFlagsAndAttributes, 
                                DWORD hTemplateFile);
BOOL    WINAPI  CloseHandle    (DWORD hObject);

/************************************************************************/
/************************************************************************/
DWORD FAR PASCAL FIOFndFst (const char FAR *lpFilNam, LPWIN32_FIND_DATAA lpFndDat)
{
    DWORD   ulRetHdl;
    static  FARPROC lpFindFirstFile = NULL;

    /********************************************************************/
    /********************************************************************/
    if (!W32Glo.hKrnW32) {
        struct _find_t FAR * lpDOSFnd;
        /****************************************************************/
        /* Allocate memory for DOS find file structure                  */
        /****************************************************************/
        if (NULL == (lpDOSFnd = GloAloLck (GMEM_MOVEABLE, &ulRetHdl, 
            sizeof (struct _find_t)))) {
            return (INVALID_HANDLE_VALUE);
        }
        /****************************************************************/
        /* Find first file                                              */
        /****************************************************************/
        if (0 != l_dos_findfirst (lpFilNam, _A_NORMAL | _A_RDONLY | 
            _A_HIDDEN | _A_SYSTEM | _A_VOLID | _A_SUBDIR | _A_ARCH, lpDOSFnd))    {
            GloUnLRel (ulRetHdl); 
            return (INVALID_HANDLE_VALUE);
        }
        /****************************************************************/
        /* Adjust values to match FILE_ constants                       */
        /****************************************************************/
        if (_A_NORMAL == (lpFndDat->dwFileAttributes = lpDOSFnd->attrib))
            lpFndDat->dwFileAttributes |= FILE_ATTRIBUTE_NORMAL;
        lpFndDat->nFileSizeHigh = 0L;
        lpFndDat->nFileSizeLow  = lpDOSFnd->size;
        _fstrlwr (_fstrcpy (lpFndDat->cFileName, lpDOSFnd->name));
        _fstrlwr (_fstrcpy (lpFndDat->cAlternateFileName, lpDOSFnd->name));
        return (ulRetHdl);
    }

    /********************************************************************/
    /* Get the address of FindFirstFileA in KERNEL32.DLL                */
    /********************************************************************/
    if (!lpFindFirstFile && !(lpFindFirstFile = (FARPROC) W32Glo.GetProcAddress32W 
        (W32Glo.hKrnW32, (LPCSTR) "FindFirstFileA"))) {
        MessageBox (NULL, "GetProcAddress32W Failed", "FILFIO", MB_OK);
        return (INVALID_HANDLE_VALUE);
    }

    /********************************************************************/
    /********************************************************************/
    ulRetHdl = W32Glo._CallProcEx32W (CPEX_DEST_STDCALL | 2L, 0x3L, lpFindFirstFile, 
        lpFilNam, lpFndDat);

    /********************************************************************/
    /* FindFirstFileA() does not copy short name if short name only.    */
    /* If short file name, copy to alternate as well.                   */
    /********************************************************************/
    if ('\0' == *lpFndDat->cAlternateFileName) _fstrncpy (lpFndDat->cAlternateFileName,
        lpFndDat->cFileName, sizeof (lpFndDat->cAlternateFileName));

// Future: Strip off "." and ".." from long file name directory search

    /********************************************************************/
    /********************************************************************/
    return (ulRetHdl);
}

DWORD FAR PASCAL FIOFndNxt (DWORD hFndFil, LPWIN32_FIND_DATAA lpFndDat)
{
    DWORD   ulRetCod;
    static  FARPROC lpFindNextFile = NULL;

    /********************************************************************/
    /********************************************************************/
    if (!W32Glo.hKrnW32) {
        struct _find_t FAR * lpDOSFnd;
        /****************************************************************/
        /* Lock memory for DOS find file structure                      */
        /****************************************************************/
        if (NULL == (lpDOSFnd = GloMemLck (hFndFil))) return (FALSE);

        /****************************************************************/
        /* Find next file                                               */
        /****************************************************************/
        if (0 != l_dos_findnext (lpDOSFnd)) return (FALSE);

        /****************************************************************/
        /* Adjust values to match FILE_ constants                       */
        /****************************************************************/
        if (_A_NORMAL == (lpFndDat->dwFileAttributes = lpDOSFnd->attrib))
            lpFndDat->dwFileAttributes |= FILE_ATTRIBUTE_NORMAL;
        lpFndDat->nFileSizeHigh = 0L;
        lpFndDat->nFileSizeLow  = lpDOSFnd->size;
        _fstrlwr (_fstrcpy (lpFndDat->cFileName, lpDOSFnd->name));
        _fstrlwr (_fstrcpy (lpFndDat->cAlternateFileName, lpDOSFnd->name));
        GloMemUnL (hFndFil);
        return (TRUE);
    }

    /********************************************************************/
    /* Get the address of FindNextFileA in KERNEL32.DLL                 */
    /********************************************************************/
    if (!lpFindNextFile && !(lpFindNextFile = (FARPROC) W32Glo.GetProcAddress32W 
        (W32Glo.hKrnW32, (LPCSTR) "FindNextFileA"))) {
        MessageBox (NULL, "GetProcAddress32W Failed", "FILFIO", MB_OK);
        return (FALSE);
    }

    /********************************************************************/
    /********************************************************************/
    ulRetCod = W32Glo._CallProcEx32W (CPEX_DEST_STDCALL | 2L, 0x2L, lpFindNextFile, 
        hFndFil, lpFndDat);

    /********************************************************************/
    /* FindNextFileA() does not copy short name if short name only.     */
    /* If short file name, copy to alternate as well.                   */
    /********************************************************************/
    if ('\0' == *lpFndDat->cAlternateFileName) _fstrncpy (lpFndDat->cAlternateFileName,
         lpFndDat->cFileName, sizeof (lpFndDat->cAlternateFileName));

// Future: Strip off "." and ".." from long file name directory search

    /********************************************************************/
    /********************************************************************/
    return (ulRetCod);
}

DWORD FAR PASCAL FIOFndEnd (DWORD hFndFil)
{
    DWORD   ulRetCod;
    static  FARPROC lpFindClose = NULL;

    /********************************************************************/
    /********************************************************************/
    if (!W32Glo.hKrnW32) {
        GloAloRel (hFndFil);
        return (TRUE);
    }

    /********************************************************************/
    /* Get the address of FindClose in KERNEL32.DLL                     */
    /********************************************************************/
    if (!lpFindClose && !(lpFindClose = (FARPROC) W32Glo.GetProcAddress32W 
        (W32Glo.hKrnW32, (LPCSTR) "FindClose"))) {
        MessageBox (NULL, "GetProcAddress32W Failed", "FILFIO", MB_OK);
        return (FALSE);
    }

    /********************************************************************/
    /********************************************************************/
    ulRetCod = W32Glo._CallProcEx32W (CPEX_DEST_STDCALL | 1L, 0x0L, lpFindClose, 
        hFndFil);

    /********************************************************************/
    /********************************************************************/
    return (ulRetCod);
}

/************************************************************************/
/************************************************************************/
HFILE   WINAPI OpenFileEx_V (LPCSTR szFilNam, LPOFSTRUCT_V pofFilOFS,
        UINT uiOpnFlg) 
{
    WIN32_FIND_DATAA    fdFndDat;
    SECURITY_ATTRIBUTES saSecurityAttributes;
    static  FARPROC     lpCreateFile    = NULL; 
    static  FARPROC     lpCloseHandle   = NULL; 
    static  FARPROC     lpFindFirstFile = NULL;
    DWORD   ulRetHdl;


if (W32Glo.hKrnW32) {

    /********************************************************************/
    /* Do we have to create a long file name?                           */
    /********************************************************************/
    if (OF_CREATE & uiOpnFlg) {
        /****************************************************************/
        /* Initialize security attributes to "none".                    */
        /****************************************************************/
        saSecurityAttributes.nLength = sizeof (saSecurityAttributes); 
        saSecurityAttributes.lpSecurityDescriptor = NULL; 
        saSecurityAttributes.bInheritHandle = FALSE; 

        /****************************************************************/
        /* Get the address of CreateFileA in KERNEL32.DLL               */
        /****************************************************************/
        if (!lpCreateFile && !(lpCreateFile = (FARPROC) W32Glo.GetProcAddress32W 
            (W32Glo.hKrnW32, (LPCSTR) "CreateFileA"))) {
            MessageBox (NULL, "GetProcAddress32W Failed", "FILFIO", MB_OK);
            return ((HFILE) -1);
        }
        if (!lpCloseHandle && !(lpCloseHandle = (FARPROC) W32Glo.GetProcAddress32W 
            (W32Glo.hKrnW32, (LPCSTR) "CloseHandle"))) {
            MessageBox (NULL, "GetProcAddress32W Failed", "FILFIO", MB_OK);
            return ((HFILE) -1);
        }

        /****************************************************************/
        /****************************************************************/
MessageBox (NULL, szFilNam, "Creating:", IDOK);
        ulRetHdl = W32Glo._CallProcEx32W (CPEX_DEST_STDCALL | 7L, 0x9L, lpCreateFile, 
            szFilNam, 0L, 0L, (LPVOID) &saSecurityAttributes, CREATE_ALWAYS, 
            FILE_ATTRIBUTE_NORMAL, NULL);
        if (INVALID_HANDLE_VALUE == ulRetHdl) {
//ajm: better error message!
            MessageBox (NULL, "Error creating file", "FILFIO", MB_OK);
            return ((HFILE) -1);
        }
        ulRetHdl = W32Glo._CallProcEx32W (CPEX_DEST_STDCALL | 1L, 0x0L, lpCloseHandle, 
            ulRetHdl);
    } 

    /********************************************************************/
    /* Initialize the FindFile data structure.                          */
    /********************************************************************/
    _fmemset (&fdFndDat, 0, sizeof (fdFndDat));
     fdFndDat.dwFileAttributes |= FILE_ATTRIBUTE_NORMAL;

    /********************************************************************/
    /* Get the address of FindFirstFileA in KERNEL32.DLL                */
    /********************************************************************/
    if (!lpFindFirstFile && !(lpFindFirstFile = (FARPROC) W32Glo.GetProcAddress32W 
        (W32Glo.hKrnW32, (LPCSTR) "FindFirstFileA"))) {
        MessageBox (NULL, "GetProcAddress32W Failed", "FILFIO", MB_OK);
        return ((HFILE) -1);
    }
    /********************************************************************/
    /********************************************************************/
MessageBox (NULL, szFilNam, "Finding:", IDOK);
    ulRetHdl = W32Glo._CallProcEx32W (CPEX_DEST_STDCALL | 2L, 0x3L, lpFindFirstFile, 
        szFilNam, (LPWIN32_FIND_DATAA) &fdFndDat);

    /********************************************************************/
    /* FindFirstFileA() does not copy short name if short name only.    */
    /* If short file name, copy to alternate as well.                   */
    /********************************************************************/
    if ('\0' == fdFndDat.cAlternateFileName[0]) _fstrncpy (fdFndDat.cAlternateFileName,
        fdFndDat.cFileName, sizeof (fdFndDat.cAlternateFileName));

MessageBox (NULL, fdFndDat.cAlternateFileName, "Setting:", IDOK);
szFilNam = fdFndDat.cAlternateFileName;
}
    
    /********************************************************************/
    /* Now open using short file name                                   */
    /********************************************************************/
    {
        HFILE   hFilHdl;
        LPBYTE  lpFilOFS = (LPBYTE) pofFilOFS;
MessageBox (NULL, szFilNam, "Opening:", IDOK);
        _fmemmove (&(lpFilOFS[1]), &(lpFilOFS[2]), sizeof (OFSTRUCT_V) - 2);    
        hFilHdl = OpenFile (szFilNam, (LPOFSTRUCT) pofFilOFS, uiOpnFlg);       
        _fmemmove (&(lpFilOFS[2]), &(lpFilOFS[1]), sizeof (OFSTRUCT_V) - 2);    
        lpFilOFS[1] = 0;
        return (hFilHdl);
    }


}

