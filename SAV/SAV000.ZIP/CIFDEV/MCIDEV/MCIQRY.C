/************************************************************************/
/* Media Control Query: MCIQry.c                        V2.00  07/15/94 */
/* Copyright (c) 1987-1995 Andrew J. Michalik                           */
/*                                                                      */
/************************************************************************/
#include "windows.h"                    /* Windows SDK definitions      */
#include "mmsystem.h"                   /* Windows Multi Media defs     */
#include "..\os_dev\winmem.h"           /* Generic memory supp defs     */
#include "..\os_dev\winmsg.h"           /* User message support         */
#include "..\pcmdev\genpcm.h"           /* PCM/APCM conv routine defs   */
#include "..\effdev\geneff.h"           /* Sound Effects definitions    */
#include "genmci.h"                     /* Generic MCI definitions      */
#include "mcisup.h"                     /* MCI support definitions      */
#include "mciwav.h"                     /* MCI wave definitions         */

#include <string.h>                     /* String manipulation funcs    */

/************************************************************************/
/*                      External References                             */
/************************************************************************/
extern  MCIGLO  MCIGlo;                 /* File I/O Library Globals     */

/************************************************************************/
/************************************************************************/
MCIPRO  FAR PASCAL  MCIWavEnu (MCIPRO usMCIPro, LPSTR szDesStr, WORD usMaxLen)
{
    MCI_SYSINFO_PARMS   siSysInf;
    DWORD               dwDevices;
    DWORD               ulWavFmt;

    /********************************************************************/
    /* Any Wave devices available?                                      */
    /* Note: this returns number listed, not necessarily functional     */
    /********************************************************************/
    _fmemset (&siSysInf, 0, sizeof (siSysInf));
    siSysInf.lpstrReturn = (LPSTR) (DWORD FAR *) &dwDevices;
    siSysInf.dwRetSize = sizeof (dwDevices);
    siSysInf.wDeviceType = MCI_DEVTYPE_WAVEFORM_AUDIO;
    if (mciSendCommand (NULL, MCI_SYSINFO, MCI_SYSINFO_QUANTITY,  
        (DWORD) (LPVOID) &siSysInf)) return (0);
    if (!dwDevices) return (0);

    /********************************************************************/
    /* Test if this device has any input / output capabilities          */
    /********************************************************************/
    if (GetDevCap (WAVINPPRO, &ulWavFmt) && GetDevCap (WAVOUTPRO, &ulWavFmt)) 
        return (0);

    /********************************************************************/
    /* Get "aggregate" input/output product name if available           */
    /********************************************************************/
    if (GetDevNam (usMCIPro + 1, szDesStr, usMaxLen)) return (usMCIPro + 1);

    /********************************************************************/
    /* Get "generic" device name if product name not available          */
    /********************************************************************/
    siSysInf.lpstrReturn = szDesStr;
    siSysInf.dwRetSize = usMaxLen;
    siSysInf.dwNumber = usMCIPro + 1;
    if (!mciSendCommand (NULL, MCI_SYSINFO, MCI_SYSINFO_NAME,  
        (DWORD) (LPMCI_SYSINFO_PARMS) &siSysInf)) return (usMCIPro + 1);
    return (0);
}

PCMTYP  FAR PASCAL  MCIPCMEnu (MCIPRO usMCIPro, PCMTYP usPCMTyp)
{
    DWORD       ulWavFmt;

    /********************************************************************/
    /********************************************************************/
    if (GetDevCap (usMCIPro, &ulWavFmt)) return (0);

    /********************************************************************/
    /* Check non-standard & standard PCM types                          */
    /********************************************************************/
    if ((usPCMTyp < DLGPCM004) && (
        MCICapQry (usMCIPro, DLGPCM004, 1, 6000L) ||
        MCICapQry (usMCIPro, DLGPCM004, 1, 8000L))) return (DLGPCM004);

    if ((usPCMTyp < DLGPCM008) && (
        MCICapQry (usMCIPro, DLGPCM008, 1, 6000L) ||
        MCICapQry (usMCIPro, DLGPCM008, 1, 8000L))) return (DLGPCM008);

    if ((usPCMTyp < G11PCMF08) && (
        MCICapQry (usMCIPro, G11PCMF08, 1, 6000L) ||
        MCICapQry (usMCIPro, G11PCMF08, 1, 8000L))) return (G11PCMF08);

    if ((usPCMTyp < G11PCMI08) && (
        MCICapQry (usMCIPro, G11PCMI08, 1, 6000L) ||
        MCICapQry (usMCIPro, G11PCMI08, 1, 8000L))) return (G11PCMI08);


    if ((usPCMTyp < MPCPCM008) && (
        (ulWavFmt & WAVE_FORMAT_1M08) ||
        (ulWavFmt & WAVE_FORMAT_1S08) ||
        (ulWavFmt & WAVE_FORMAT_2M08) ||
        (ulWavFmt & WAVE_FORMAT_2S08) ||
        (ulWavFmt & WAVE_FORMAT_4M08) ||
        (ulWavFmt & WAVE_FORMAT_4S08))) return (MPCPCM008);

    if ((usPCMTyp < MPCPCM016) && (
        (ulWavFmt & WAVE_FORMAT_1M16) ||
        (ulWavFmt & WAVE_FORMAT_1S16) ||
        (ulWavFmt & WAVE_FORMAT_2M16) ||
        (ulWavFmt & WAVE_FORMAT_2S16) ||
        (ulWavFmt & WAVE_FORMAT_4M16) ||
        (ulWavFmt & WAVE_FORMAT_4S16))) return (MPCPCM016);

    /********************************************************************/
    /********************************************************************/
    return (0);
}

WORD    FAR PASCAL  MCIChnEnu (MCIPRO usMCIPro, PCMTYP usPCMTyp, WORD usChnCnt)
{
    DWORD       ulWavFmt;

    /********************************************************************/
    /********************************************************************/
    if (GetDevCap (usMCIPro, &ulWavFmt)) return (0);

    /********************************************************************/
    /********************************************************************/
    switch (usPCMTyp) {
        case MPCPCM008:
            if ((usChnCnt < 1) && (
                (ulWavFmt & WAVE_FORMAT_1M08) || 
                (ulWavFmt & WAVE_FORMAT_2M08) || 
                (ulWavFmt & WAVE_FORMAT_4M08))) return (1);
            if ((usChnCnt < 2) && (
                (ulWavFmt & WAVE_FORMAT_1S08) || 
                (ulWavFmt & WAVE_FORMAT_2S08) || 
                (ulWavFmt & WAVE_FORMAT_4S08))) return (2);
            break;
        case MPCPCM016:
            if ((usChnCnt < 1) && (
                (ulWavFmt & WAVE_FORMAT_1M16) || 
                (ulWavFmt & WAVE_FORMAT_2M16) || 
                (ulWavFmt & WAVE_FORMAT_4M16))) return (1);
            if ((usChnCnt < 2) && (
                (ulWavFmt & WAVE_FORMAT_1S16) || 
                (ulWavFmt & WAVE_FORMAT_2S16) || 
                (ulWavFmt & WAVE_FORMAT_4S16))) return (2);
            break;
    }

    /********************************************************************/
    /********************************************************************/
    return (0);
}

DWORD   FAR PASCAL  MCIFrqEnu (MCIPRO usMCIPro, PCMTYP usPCMTyp, WORD usChnCnt, DWORD ulSmpFrq)
{
    DWORD       ulWavFmt;

    /********************************************************************/
    /********************************************************************/
    if (GetDevCap (usMCIPro, &ulWavFmt)) return (0);

    /********************************************************************/
    /********************************************************************/
    switch (usPCMTyp) {
        case DLGPCM004: switch (usChnCnt) {
          case 1: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, DLGPCM004, 1, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, DLGPCM004, 1, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (MCICapQry (usMCIPro, DLGPCM004, 1, 8000L))) return (11025L);
            if ((ulSmpFrq < 22050L) && (MCICapQry (usMCIPro, DLGPCM004, 1, 8000L))) return (22050L);
            if ((ulSmpFrq < 44100L) && (MCICapQry (usMCIPro, DLGPCM004, 1, 8000L))) return (44100L);
            break;
        }
        case DLGPCM008: switch (usChnCnt) {
          case 1: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, DLGPCM008, 1, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, DLGPCM008, 1, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (MCICapQry (usMCIPro, DLGPCM008, 1, 8000L))) return (11025L);
            if ((ulSmpFrq < 22050L) && (MCICapQry (usMCIPro, DLGPCM008, 1, 8000L))) return (22050L);
            if ((ulSmpFrq < 44100L) && (MCICapQry (usMCIPro, DLGPCM008, 1, 8000L))) return (44100L);
            break;
        }
        case G11PCMF08: switch (usChnCnt) {
          case 1: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, G11PCMF08, 1, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, G11PCMF08, 1, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (MCICapQry (usMCIPro, G11PCMF08, 1, 8000L))) return (11025L);
            if ((ulSmpFrq < 22050L) && (MCICapQry (usMCIPro, G11PCMF08, 1, 8000L))) return (22050L);
            if ((ulSmpFrq < 44100L) && (MCICapQry (usMCIPro, G11PCMF08, 1, 8000L))) return (44100L);
            break;
        }
        case G11PCMI08: switch (usChnCnt) {
          case 1: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, G11PCMI08, 1, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, G11PCMI08, 1, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (MCICapQry (usMCIPro, G11PCMI08, 1, 8000L))) return (11025L);
            if ((ulSmpFrq < 22050L) && (MCICapQry (usMCIPro, G11PCMI08, 1, 8000L))) return (22050L);
            if ((ulSmpFrq < 44100L) && (MCICapQry (usMCIPro, G11PCMI08, 1, 8000L))) return (44100L);
            break;
        }
        case MPCPCM008: switch (usChnCnt) {
          case 1: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, MPCPCM008, 1, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, MPCPCM008, 1, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (ulWavFmt & WAVE_FORMAT_1M08)) return (11025L);
            if ((ulSmpFrq < 22050L) && (ulWavFmt & WAVE_FORMAT_2M08)) return (22050L);
            if ((ulSmpFrq < 44100L) && (ulWavFmt & WAVE_FORMAT_4M08)) return (44100L);
            break;
          case 2: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, MPCPCM008, 2, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, MPCPCM008, 2, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (ulWavFmt & WAVE_FORMAT_1S08)) return (11025L);
            if ((ulSmpFrq < 22050L) && (ulWavFmt & WAVE_FORMAT_2S08)) return (22050L);
            if ((ulSmpFrq < 44100L) && (ulWavFmt & WAVE_FORMAT_4S08)) return (44100L);
            break;
        }                
        break;
        case MPCPCM016: switch (usChnCnt) {
          case 1: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, MPCPCM016, 1, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, MPCPCM016, 1, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (ulWavFmt & WAVE_FORMAT_1M16)) return (11025L);
            if ((ulSmpFrq < 22050L) && (ulWavFmt & WAVE_FORMAT_2M16)) return (22050L);
            if ((ulSmpFrq < 44100L) && (ulWavFmt & WAVE_FORMAT_4M16)) return (44100L);
            break;
          case 2: 
            if ((ulSmpFrq <  6000L) && (MCICapQry (usMCIPro, MPCPCM016, 2, 6000L))) return (6000L);
            if ((ulSmpFrq <  8000L) && (MCICapQry (usMCIPro, MPCPCM016, 2, 8000L))) return (8000L);
            if ((ulSmpFrq < 11025L) && (ulWavFmt & WAVE_FORMAT_1S16)) return (11025L);
            if ((ulSmpFrq < 22050L) && (ulWavFmt & WAVE_FORMAT_2S16)) return (22050L);
            if ((ulSmpFrq < 44100L) && (ulWavFmt & WAVE_FORMAT_4S16)) return (44100L);
            break;
        }                
        break;
    }

    /********************************************************************/
    /********************************************************************/
    return (0L);
}

WORD    FAR PASCAL  MCICapQry (MCIPRO usMCIPro, PCMTYP usPCMTyp, WORD usChnCnt, DWORD ulSmpFrq)
{
    PCMWAVEFORMAT   wfWavFmt; 
    WORD            usRetCod;

    /********************************************************************/
    /********************************************************************/
    switch (usPCMTyp) {
        case DLGPCM004:
            wfWavFmt.wf.wFormatTag = WAVE_FORMAT_DIALOGIC_OKI_ADPCM;
            wfWavFmt.wBitsPerSample = 4;
            wfWavFmt.wf.nBlockAlign = 1;
            break;
        case DLGPCM008: 
        case G11PCMF08: 
            wfWavFmt.wf.wFormatTag = WAVE_FORMAT_MULAW;
            wfWavFmt.wBitsPerSample = 8;
            wfWavFmt.wf.nBlockAlign = 1;
            break;
        case G11PCMI08: 
            wfWavFmt.wf.wFormatTag = WAVE_FORMAT_ALAW;
            wfWavFmt.wBitsPerSample = 8;
            wfWavFmt.wf.nBlockAlign = 1;
            break;
        case MPCPCM008: 
            wfWavFmt.wf.wFormatTag = WAVE_FORMAT_PCM;
            wfWavFmt.wBitsPerSample = 8;
            wfWavFmt.wf.nBlockAlign = 1;
            break;
        case MPCPCM016: 
            wfWavFmt.wf.wFormatTag = WAVE_FORMAT_PCM;
            wfWavFmt.wBitsPerSample = 16;
            wfWavFmt.wf.nBlockAlign = 2;
            break;
        default:
            return (FALSE);
    }
    wfWavFmt.wf.nChannels = usChnCnt;
    wfWavFmt.wf.nSamplesPerSec = ulSmpFrq;
    wfWavFmt.wf.nAvgBytesPerSec    
        = wfWavFmt.wf.nSamplesPerSec * wfWavFmt.wBitsPerSample / 8L;

    /********************************************************************/
    /* Make sure a waveform output device supports this format.         */
    /********************************************************************/
    switch (usMCIPro) {
        case WAVINPPRO:
// ajm
// Disable mapper
usRetCod = TRUE;
//            usRetCod = waveInOpen (NULL, (UINT) WAVE_MAPPER, 
//              (LPWAVEFORMAT) &wfWavFmt, NULL, 0L, 
//              (DWORD) (WAVE_FORMAT_QUERY | WAVE_ALLOWSYNC));
            if (usRetCod) usRetCod = waveInOpen (NULL, WAVDEV1ST, 
              (LPWAVEFORMAT) &wfWavFmt, NULL, 0L, 
              (DWORD) (WAVE_FORMAT_QUERY | WAVE_ALLOWSYNC));
            return (0 == usRetCod);
        case WAVOUTPRO:
// ajm
// Disable mapper
usRetCod = TRUE;
//            usRetCod = waveOutOpen (NULL, (UINT) WAVE_MAPPER, 
//              (LPWAVEFORMAT) &wfWavFmt, NULL, 0L, 
//              (DWORD) (WAVE_FORMAT_QUERY | WAVE_ALLOWSYNC));
            if (usRetCod) usRetCod = waveOutOpen (NULL, WAVDEV1ST, 
              (LPWAVEFORMAT) &wfWavFmt, NULL, 0L, 
              (DWORD) (WAVE_FORMAT_QUERY | WAVE_ALLOWSYNC));
            return (0 == usRetCod);
    }

    /********************************************************************/
    /********************************************************************/
    return (FALSE);

}

/************************************************************************/
/************************************************************************/
WORD    GetDevCap (MCIPRO usMCIPro, DWORD FAR *pulWavFmt)
{
    WAVEINCAPS  wcInpCap;
    WAVEOUTCAPS wcOutCap;
    WORD        usRetCod;

    /********************************************************************/
    /********************************************************************/
    switch (usMCIPro) {
        case WAVINPPRO:
// ajm
// Disable mapper
usRetCod = TRUE;
//            usRetCod = waveInGetDevCaps ((UINT) WAVE_MAPPER, &wcInpCap, sizeof (WAVEINCAPS));
            if (usRetCod) usRetCod = waveInGetDevCaps (WAVDEV1ST, &wcInpCap, sizeof (WAVEINCAPS));  
            break;
        case WAVOUTPRO:
// ajm
// Disable mapper
usRetCod = TRUE;
//            usRetCod = waveOutGetDevCaps ((UINT) WAVE_MAPPER, &wcOutCap, sizeof (WAVEOUTCAPS));
            if (usRetCod) usRetCod = waveOutGetDevCaps (WAVDEV1ST, &wcOutCap, sizeof (WAVEOUTCAPS));  
            break;
        default:
            return ((WORD) -1);
    }

    /********************************************************************/
    /********************************************************************/
    *pulWavFmt = usRetCod ? 0L : wcOutCap.dwFormats; 
    return (usRetCod);

}

WORD    GetDevNam (MCIPRO usMCIPro, LPSTR pszDevNam, WORD usMaxLen)
{
    WAVEINCAPS  wcInpCap;
    WAVEOUTCAPS wcOutCap;
    char        szNamInp[MAXPNAMELEN] = {'\0'};
    char        szNamOut[MAXPNAMELEN] = {'\0'}; 
    WORD        usi;

    /********************************************************************/
    /********************************************************************/
	if (!usMaxLen) return (0);
    *pszDevNam = '\0';

    /********************************************************************/
    /* Get input device name                                            */
    /********************************************************************/
    if (0 == waveInGetDevCaps (WAVDEV1ST, &wcInpCap, sizeof (WAVEINCAPS))) {
        _fstrncpy (szNamInp, wcInpCap.szPname, MAXPNAMELEN);
    }  

    /********************************************************************/
    /* Get output device name                                           */
    /********************************************************************/
    if (0 == waveOutGetDevCaps (WAVDEV1ST, &wcOutCap, sizeof (WAVEOUTCAPS))) {
        _fstrncpy (szNamOut, wcOutCap.szPname, MAXPNAMELEN);
    }  

    /********************************************************************/
    /* Find simularities                                                */
    /********************************************************************/
    for (usi = 0; usi < min (usMaxLen-1, MAXPNAMELEN-1); usi++) {
		if (szNamInp[usi] == szNamOut[usi]) pszDevNam[usi] = szNamOut[usi];	
        else break;
		if ('\0' == pszDevNam[usi]) break;	
	}
	pszDevNam[usi] = '\0';

    /********************************************************************/
    /* Append generic type name                                         */
    /********************************************************************/
    MsgLodStr (MCIGlo.hLibIns, SI_MCIWAVGEN, &pszDevNam[usi], usMaxLen - usi);

    /********************************************************************/
    /********************************************************************/
    return (_fstrlen (pszDevNam));
}
